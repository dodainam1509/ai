package com.omnia.ai

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject

private val AppBg = Color(0xFF090D18)
private val Surface2 = Color(0xFF151D2E)
private val Accent2 = Color(0xFF8B9BFF)
private val SecondaryText = Color(0xFFAAB5CC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OmniaTheme { OmniaApp() } }
    }
}

data class AgentInfo(val name: String, val role: String, val url: String, val selected: Boolean = false)
data class LogItem(val author: String, val text: String, val time: Long = System.currentTimeMillis())
data class OmniaState(
    val page: Int = 0,
    val taskInput: String = "",
    val activeTask: String = "",
    val status: String = "Không có quy trình đang chạy",
    val agents: List<AgentInfo> = defaultAgents(),
    val logs: List<LogItem> = listOf(LogItem("OMNIA", "Không gian làm việc đã sẵn sàng. Tạo nhiệm vụ hoặc ghi chú trong phòng họp."))
)

private fun defaultAgents() = listOf(
    AgentInfo("ChatGPT", "Điều phối, viết và tổng hợp", "https://chatgpt.com"),
    AgentInfo("Claude", "Phân tích và phản biện", "https://claude.ai"),
    AgentInfo("Gemini", "Nghiên cứu và đa phương thức", "https://gemini.google.com"),
    AgentInfo("Grok", "Góc nhìn và ý tưởng bổ sung", "https://grok.com"),
    AgentInfo("DeepSeek", "Lập luận và hỗ trợ kỹ thuật", "https://chat.deepseek.com"),
    AgentInfo("Muse AI", "Sáng tạo nội dung", "https://muse.ai")
)

class OmniaViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("omnia_local", 0)
    private val _state = MutableStateFlow(loadState())
    val state: StateFlow<OmniaState> = _state

    private fun loadState(): OmniaState {
        val task = prefs.getString("active_task", "") ?: ""
        val status = prefs.getString("status", "Không có quy trình đang chạy") ?: "Không có quy trình đang chạy"
        val logs = mutableListOf<LogItem>()
        try {
            val arr = JSONArray(prefs.getString("logs", "[]"))
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                logs.add(LogItem(obj.optString("author"), obj.optString("text"), obj.optLong("time")))
            }
        } catch (_: Exception) { }
        val selected = prefs.getStringSet("selected_agents", emptySet()) ?: emptySet()
        return OmniaState(
            activeTask = task,
            status = status,
            agents = defaultAgents().map { it.copy(selected = selected.contains(it.name)) },
            logs = logs.ifEmpty { listOf(LogItem("OMNIA", "Không gian làm việc đã sẵn sàng.")) }
        )
    }

    private fun persist(s: OmniaState) {
        prefs.edit()
            .putString("active_task", s.activeTask)
            .putString("status", s.status)
            .putStringSet("selected_agents", s.agents.filter { it.selected }.map { it.name }.toSet())
            .putString("logs", JSONArray().apply {
                s.logs.takeLast(250).forEach { item ->
                    put(JSONObject().put("author", item.author).put("text", item.text).put("time", item.time))
                }
            }.toString())
            .apply()
    }

    private fun change(block: (OmniaState) -> OmniaState) {
        _state.update { old -> block(old).also(::persist) }
    }

    fun setPage(page: Int) = change { it.copy(page = page) }
    fun setTask(value: String) { _state.update { it.copy(taskInput = value) } }

    fun createWorkflow() {
        val task = _state.value.taskInput.trim()
        if (task.isEmpty()) {
            change { it.copy(status = "Nhập mô tả nhiệm vụ trước khi tạo quy trình.") }
            return
        }
        change { old ->
            old.copy(
                activeTask = task,
                status = "Đã lưu nhiệm vụ · chờ bạn gửi tới các AI đã chọn",
                logs = old.logs + LogItem("OMNIA", "Đã tạo nhiệm vụ: $task") +
                    LogItem("OMNIA", "Gợi ý phân vai: ChatGPT tổng hợp; Claude phản biện; Gemini nghiên cứu; DeepSeek kiểm tra logic. Đây là kế hoạch điều phối, chưa phải kết quả do AI tạo.")
            )
        }
    }

    fun addMessage(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        change { it.copy(logs = it.logs + LogItem("Bạn", clean)) }
    }

    fun toggleAgent(name: String) = change { old ->
        old.copy(agents = old.agents.map { if (it.name == name) it.copy(selected = !it.selected) else it })
    }

    fun clearHistory() = change { it.copy(logs = emptyList(), activeTask = "", status = "Đã xóa lịch sử trên thiết bị") }
}

@Composable
private fun OmniaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent2, background = AppBg, surface = Surface2,
            onBackground = Color.White, onSurface = Color.White,
            secondary = Color(0xFF70D6C3)
        ), content = content
    )
}

@Composable
private fun OmniaApp(vm: OmniaViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    Scaffold(
        containerColor = AppBg,
        bottomBar = {
            NavigationBar(containerColor = Surface2) {
                val labels = listOf("Nhiệm vụ", "Phòng họp", "AI & tài khoản")
                val icons = listOf(Icons.Default.Dashboard, Icons.Default.Groups, Icons.Default.Hub)
                labels.forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = state.page == index,
                        onClick = { vm.setPage(index) },
                        icon = { Icon(icons[index], contentDescription = label) },
                        label = { Text(label, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Accent2, selectedTextColor = Accent2,
                            indicatorColor = Color(0xFF293452), unselectedTextColor = SecondaryText
                        )
                    )
                }
            }
        }
    ) { padding ->
        when (state.page) {
            0 -> TaskScreen(state, vm, Modifier.padding(padding))
            1 -> MeetingScreen(state, vm, Modifier.padding(padding))
            else -> ProviderScreen(state, vm, Modifier.padding(padding))
        }
    }
}

@Composable
private fun Header(kicker: String, title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
        Text(kicker.uppercase(), color = Accent2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Text(title, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
        Text(subtitle, color = SecondaryText, fontSize = 12.sp)
    }
}

@Composable
private fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Surface2)
    ) { Column(Modifier.padding(16.dp), content = content) }
}

@Composable
private fun TaskScreen(s: OmniaState, vm: OmniaViewModel, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp).padding(top = 26.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Header("Multi-agent workspace", "OMNIA AI", "Một không gian để lập kế hoạch và phối hợp nhiều trợ lý AI")
        Panel {
            Text("TẠO NHIỆM VỤ", color = Accent2, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = s.taskInput, onValueChange = vm::setTask,
                modifier = Modifier.fillMaxWidth().heightIn(min = 118.dp),
                placeholder = { Text("Mô tả công việc bạn muốn thực hiện…", color = SecondaryText) },
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Accent2, unfocusedBorderColor = Color(0xFF3A4660),
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White
                )
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = vm::createWorkflow, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                Icon(Icons.Default.AutoAwesome, null)
                Spacer(Modifier.width(8.dp))
                Text("Lập kế hoạch nhiệm vụ")
            }
        }
        Panel {
            Text("TRẠNG THÁI", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(7.dp))
            Text(s.status, color = SecondaryText, fontSize = 13.sp)
            if (s.activeTask.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Text("Nhiệm vụ hiện tại", color = Accent2, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(s.activeTask, color = Color.White, fontSize = 14.sp)
            }
        }
        Panel {
            Text("QUY TRÌNH LÀM VIỆC", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            WorkflowStep("01", "Phân tích yêu cầu", "Xác định mục tiêu và đầu ra")
            WorkflowStep("02", "Phân vai AI", "Chọn các nhà cung cấp có thể sử dụng")
            WorkflowStep("03", "Đối chiếu kết quả", "Kiểm tra chéo và ghi nhận ý kiến")
            WorkflowStep("04", "Tổng hợp", "Lưu kết quả cuối cùng vào không gian làm việc")
        }
        Text("Dữ liệu nhiệm vụ được lưu cục bộ trên thiết bị.", color = SecondaryText, fontSize = 11.sp)
    }
}

@Composable
private fun WorkflowStep(number: String, title: String, description: String) {
    Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(32.dp).background(Color(0xFF293452), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
            Text(number, color = Accent2, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(description, color = SecondaryText, fontSize = 11.sp)
        }
    }
}

@Composable
private fun MeetingScreen(s: OmniaState, vm: OmniaViewModel, modifier: Modifier = Modifier) {
    var message by remember { mutableStateOf("") }
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp).padding(top = 24.dp)) {
        Header("Shared workspace", "Phòng họp AI", "Ghi chú, trao đổi và lưu tiến độ của phiên làm việc")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = vm::clearHistory) {
                Icon(Icons.Default.DeleteOutline, null, tint = SecondaryText)
                Text("Xóa lịch sử", color = SecondaryText)
            }
        }
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            items(s.logs) { entry ->
                Panel {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(entry.author, color = Accent2, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(Modifier.weight(1f))
                        Text(java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(entry.time)), color = SecondaryText, fontSize = 10.sp)
                    }
                    Spacer(Modifier.height(5.dp))
                    Text(entry.text, color = Color.White, fontSize = 13.sp, lineHeight = 19.sp)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = message, onValueChange = { message = it },
                modifier = Modifier.weight(1f), placeholder = { Text("Nhập ghi chú hoặc nội dung…", color = SecondaryText) },
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent2, unfocusedBorderColor = Color(0xFF3A4660))
            )
            IconButton(onClick = { vm.addMessage(message); message = "" }) {
                Icon(Icons.Default.Send, contentDescription = "Gửi", tint = Accent2)
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ProviderScreen(s: OmniaState, vm: OmniaViewModel, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    Column(modifier.fillMaxSize().padding(horizontal = 18.dp).padding(top = 24.dp)) {
        Header("Provider directory", "AI & tài khoản", "Chọn các dịch vụ bạn muốn dùng trong quy trình")
        Panel {
            Text("GIỚI HẠN TÍCH HỢP", color = Accent2, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            Spacer(Modifier.height(7.dp))
            Text(
                "Các lựa chọn bên dưới chưa phải phiên đăng nhập được kết nối. OMNIA chỉ có thể điều khiển mô hình qua API/OAuth/SDK mà nhà cung cấp chính thức cho phép. Nút Mở dịch vụ đưa bạn tới trang chính thức; việc đăng nhập tại đó không tự cấp quyền truy cập cho OMNIA.",
                color = SecondaryText, fontSize = 12.sp, lineHeight = 18.sp
            )
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(s.agents) { agent ->
                Panel {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(agent.name, fontWeight = FontWeight.Bold)
                            Text(agent.role, color = SecondaryText, fontSize = 11.sp)
                            Text(if (agent.selected) "Đã chọn cho kế hoạch" else "Chưa chọn", color = if (agent.selected) Accent2 else SecondaryText, fontSize = 10.sp)
                        }
                        Switch(checked = agent.selected, onCheckedChange = { vm.toggleAgent(agent.name) })
                    }
                    Spacer(Modifier.height(7.dp))
                    OutlinedButton(
                        onClick = {
                            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(agent.url))) }
                        }, modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.OpenInNew, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Mở ${agent.name}")
                    }
                }
            }
        }
    }
}
