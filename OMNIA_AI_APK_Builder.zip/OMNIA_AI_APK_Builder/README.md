# OMNIA AI — Android app starter (Vietnamese)

A native Android app built with Kotlin + Jetpack Compose. The current build is an **offline-first AI workspace**: task board, meeting notes, provider directory, and saved local history.

## Build an APK with GitHub Actions

1. Create a new GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Select **Build OMNIA AI APK** and press **Run workflow** (or push to `main`).
4. When the workflow finishes, open its run and download the `OMNIA-AI-debug-apk` artifact.
5. Extract the ZIP and install `app-debug.apk` on your Android phone. This is a debug build, not a Play Store release.

The workflow installs Android SDK 35 and builds with Gradle 8.9 / JDK 17.

## Current features

- Vietnamese interface and dark theme.
- Local task creation and saved task history.
- Meeting room notes / conversation log (user-entered content).
- Provider directory for ChatGPT, Claude, Gemini, Grok, DeepSeek and Muse AI.
- Clear connection status; no fake claim that an account is connected.
- Local data stored on the device with Android SharedPreferences.

## Important provider integration limitation

A third-party app cannot simply reuse a consumer subscription or an already signed-in session from another app. Each provider must explicitly offer a permitted OAuth, SDK, or API integration. This starter does **not** scrape cookies, extract app sessions, collect provider passwords, or bypass usage limits. The provider switches are currently a directory/status feature, not live model connections. Real multi-agent execution and automatic quota fallback require provider-approved integrations and credentials/authorization for each provider.

## Technical details

- Application ID: `com.omnia.ai`
- Min SDK: 26 (Android 8.0)
- Target / Compile SDK: 35
- Kotlin + Jetpack Compose + Material 3
- Debug APK is unsigned for release distribution; use a properly signed release build before public distribution.
